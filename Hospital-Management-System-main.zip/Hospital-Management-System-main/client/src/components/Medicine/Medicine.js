import { Outlet } from "react-router-dom";

export default function Medicine() {
    return (
        <Outlet />
    )
}