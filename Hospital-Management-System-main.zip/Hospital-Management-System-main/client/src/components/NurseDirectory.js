import React, { useState } from "react";


function NurseDirectory() {
    return (
        <div> Place holder Nurse Directory</div>
    )
}

export default NurseDirectory;